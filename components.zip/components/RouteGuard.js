import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import { useAtom } from 'jotai';
import { isAuthenticated } from '@/lib/authenticate';
import { getFavourites, getHistory } from '@/lib/userData';
import { favouritesAtom, searchHistoryAtom } from '@/store';

const PUBLIC_PATHS = ['/login', '/', '/_error', '/register'];

export default function RouteGuard(props) {
  const router = useRouter();
  const [authorized, setAuthorized] = useState(false);
  const [, setFavouritesList] = useAtom(favouritesAtom);
  const [, setSearchHistory] = useAtom(searchHistoryAtom);

  const updateAtoms = async () => {
    setFavouritesList(await getFavourites());
    setSearchHistory(await getHistory());
  };

  useEffect(() => {
    // Initial auth check and atom update
    authCheck(router.pathname);
    if (isAuthenticated()) updateAtoms();

    // On route change, perform auth check
    router.events.on('routeChangeComplete', authCheck);

    // Cleanup the router event listener
    return () => {
      router.events.off('routeChangeComplete', authCheck);
    };
  }, []);

  const authCheck = (url) => {
    const path = url.split('?')[0];
    if (!isAuthenticated() && !PUBLIC_PATHS.includes(path)) {
      setAuthorized(false);
      router.push('/login');
    } else {
      setAuthorized(true);
    }
  };

  return <>{authorized && props.children}</>;
}
