import React, { useState } from 'react';
import { Navbar, Nav, Form, Button, Container, NavDropdown } from 'react-bootstrap';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useAtom } from 'jotai';
import { searchHistoryAtom } from '../store';
import { addToHistory } from '@/lib/userData'; // Import the addToHistory function

const MainNav = () => {
  const router = useRouter();
  const [searchField, setSearchField] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);

  const handleSearchSubmit = async (event) => {
    event.preventDefault();

    const queryString = `title=true&q=${searchField}`;
    
    // Add the query to the history using the API
    setSearchHistory(await addToHistory(queryString));

    // Navigate to the artwork page
    router.push(`/artwork?${queryString}`);

    // Collapse the navbar
    setIsExpanded(false);
  };

  return (
    <Navbar expanded={isExpanded} expand="lg" className="navbar-dark bg-primary fixed-top">
      <Container>
        <Navbar.Brand>Krutin Bharatbhai Polra</Navbar.Brand>
        <Navbar.Toggle aria-controls="main-navbar-nav" onClick={() => setIsExpanded(!isExpanded)} />
        <Navbar.Collapse id="main-navbar-nav">
          <Nav className="me-auto">
            <Link legacyBehavior href="/" passHref>
              <Nav.Link onClick={() => setIsExpanded(false)}>Home</Nav.Link>
            </Link>
            <Link legacyBehavior href="/search" passHref>
              <Nav.Link onClick={() => setIsExpanded(false)}>Advanced Search</Nav.Link>
            </Link>
          </Nav>
          <Form className="d-flex me-2" onSubmit={handleSearchSubmit}>
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
              value={searchField}
              onChange={(e) => setSearchField(e.target.value)}
            />
            <Button variant="outline-light" type="submit">Search</Button>
          </Form>
          <Nav>
            <NavDropdown title="User Name" id="user-dropdown" align="end" onClick={() => setIsExpanded(false)}>
              <NavDropdown.Item as={Link} href="/favourites" passHref>Favourites</NavDropdown.Item>
              <NavDropdown.Item as={Link} href="/history" passHref>History</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default MainNav;
