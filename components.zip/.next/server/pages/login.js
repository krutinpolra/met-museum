/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/login";
exports.ids = ["pages/login"];
exports.modules = {

/***/ "./styles/Login.module.css":
/*!*********************************!*\
  !*** ./styles/Login.module.css ***!
  \*********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"loginContainer\": \"Login_loginContainer__49OCD\",\n\t\"card\": \"Login_card__3dJzk\",\n\t\"heading\": \"Login_heading___Ubp0\",\n\t\"subheading\": \"Login_subheading__fygYc\",\n\t\"alert\": \"Login_alert__Gpd4j\",\n\t\"form\": \"Login_form__F7zp_\",\n\t\"label\": \"Login_label__Df2On\",\n\t\"input\": \"Login_input__GbcAp\",\n\t\"button\": \"Login_button__BuBqT\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvTG9naW4ubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9zdHlsZXMvTG9naW4ubW9kdWxlLmNzcz81NDAwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImxvZ2luQ29udGFpbmVyXCI6IFwiTG9naW5fbG9naW5Db250YWluZXJfXzQ5T0NEXCIsXG5cdFwiY2FyZFwiOiBcIkxvZ2luX2NhcmRfXzNkSnprXCIsXG5cdFwiaGVhZGluZ1wiOiBcIkxvZ2luX2hlYWRpbmdfX19VYnAwXCIsXG5cdFwic3ViaGVhZGluZ1wiOiBcIkxvZ2luX3N1YmhlYWRpbmdfX2Z5Z1ljXCIsXG5cdFwiYWxlcnRcIjogXCJMb2dpbl9hbGVydF9fR3BkNGpcIixcblx0XCJmb3JtXCI6IFwiTG9naW5fZm9ybV9fRjd6cF9cIixcblx0XCJsYWJlbFwiOiBcIkxvZ2luX2xhYmVsX19EZjJPblwiLFxuXHRcImlucHV0XCI6IFwiTG9naW5faW5wdXRfX0diY0FwXCIsXG5cdFwiYnV0dG9uXCI6IFwiTG9naW5fYnV0dG9uX19CdUJxVFwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/Login.module.css\n");

/***/ }),

/***/ "__barrel_optimize__?names=Alert,Button,Card,Form!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************************!*\
  !*** __barrel_optimize__?names=Alert,Button,Card,Form!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Alert: () => (/* reexport safe */ _Alert__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Card: () => (/* reexport safe */ _Card__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Alert__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Alert */ \"./node_modules/react-bootstrap/esm/Alert.js\");\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Card */ \"./node_modules/react-bootstrap/esm/Card.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1BbGVydCxCdXR0b24sQ2FyZCxGb3JtIT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFDMEM7QUFDRTtBQUNKIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vbm9kZV9tb2R1bGVzL3JlYWN0LWJvb3RzdHJhcC9lc20vaW5kZXguanM/MGQwMSJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQWxlcnQgfSBmcm9tIFwiLi9BbGVydFwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJ1dHRvbiB9IGZyb20gXCIuL0J1dHRvblwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENhcmQgfSBmcm9tIFwiLi9DYXJkXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRm9ybSB9IGZyb20gXCIuL0Zvcm1cIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Alert,Button,Card,Form!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!****************************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Button: () => (/* reexport safe */ _Button__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   Form: () => (/* reexport safe */ _Form__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_3__[\"default\"]),\n/* harmony export */   NavDropdown: () => (/* reexport safe */ _NavDropdown__WEBPACK_IMPORTED_MODULE_4__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_5__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Button */ \"./node_modules/react-bootstrap/esm/Button.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"./node_modules/react-bootstrap/esm/Container.js\");\n/* harmony import */ var _Form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Form */ \"./node_modules/react-bootstrap/esm/Form.js\");\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Nav */ \"./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _NavDropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./NavDropdown */ \"./node_modules/react-bootstrap/esm/NavDropdown.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Navbar */ \"./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1CdXR0b24sQ29udGFpbmVyLEZvcm0sTmF2LE5hdkRyb3Bkb3duLE5hdmJhciE9IS4vbm9kZV9tb2R1bGVzL3JlYWN0LWJvb3RzdHJhcC9lc20vaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUM0QztBQUNNO0FBQ1Y7QUFDRjtBQUNnQiIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzP2RkZDMiXSwic291cmNlc0NvbnRlbnQiOlsiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEJ1dHRvbiB9IGZyb20gXCIuL0J1dHRvblwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIENvbnRhaW5lciB9IGZyb20gXCIuL0NvbnRhaW5lclwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEZvcm0gfSBmcm9tIFwiLi9Gb3JtXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2IH0gZnJvbSBcIi4vTmF2XCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2RHJvcGRvd24gfSBmcm9tIFwiLi9OYXZEcm9wZG93blwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIE5hdmJhciB9IGZyb20gXCIuL05hdmJhclwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Flogin&preferredRegion=&absolutePagePath=.%2Fpages%5Clogin.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Flogin&preferredRegion=&absolutePagePath=.%2Fpages%5Clogin.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/future/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.js\");\n/* harmony import */ var _pages_login_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages\\login.js */ \"./pages/login.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_login_js__WEBPACK_IMPORTED_MODULE_5__]);\n([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__, _pages_login_js__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"default\"));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"getStaticProps\");\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"getStaticPaths\");\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"getServerSideProps\");\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"config\");\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"reportWebVitals\");\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticProps\");\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticPaths\");\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getStaticParams\");\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerProps\");\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_login_js__WEBPACK_IMPORTED_MODULE_5__, \"unstable_getServerSideProps\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/login\",\n        pathname: \"/login\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    components: {\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _pages_login_js__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGbG9naW4mcHJlZmVycmVkUmVnaW9uPSZhYnNvbHV0ZVBhZ2VQYXRoPS4lMkZwYWdlcyU1Q2xvZ2luLmpzJmFic29sdXRlQXBwUGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfYXBwJmFic29sdXRlRG9jdW1lbnRQYXRoPXByaXZhdGUtbmV4dC1wYWdlcyUyRl9kb2N1bWVudCZtaWRkbGV3YXJlQ29uZmlnQmFzZTY0PWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUErRjtBQUNoQztBQUNMO0FBQzFEO0FBQ29EO0FBQ1Y7QUFDMUM7QUFDOEM7QUFDOUM7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLDRDQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLHVCQUF1Qix3RUFBSyxDQUFDLDRDQUFRO0FBQ3JDLHVCQUF1Qix3RUFBSyxDQUFDLDRDQUFRO0FBQ3JDLDJCQUEyQix3RUFBSyxDQUFDLDRDQUFRO0FBQ3pDLGVBQWUsd0VBQUssQ0FBQyw0Q0FBUTtBQUM3Qix3QkFBd0Isd0VBQUssQ0FBQyw0Q0FBUTtBQUM3QztBQUNPLGdDQUFnQyx3RUFBSyxDQUFDLDRDQUFRO0FBQzlDLGdDQUFnQyx3RUFBSyxDQUFDLDRDQUFRO0FBQzlDLGlDQUFpQyx3RUFBSyxDQUFDLDRDQUFRO0FBQy9DLGdDQUFnQyx3RUFBSyxDQUFDLDRDQUFRO0FBQzlDLG9DQUFvQyx3RUFBSyxDQUFDLDRDQUFRO0FBQ3pEO0FBQ08sd0JBQXdCLHlHQUFnQjtBQUMvQztBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLFdBQVc7QUFDWCxnQkFBZ0I7QUFDaEIsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVELGlDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLz83YTI3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhZ2VzUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9wYWdlcy9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBob2lzdCB9IGZyb20gXCJuZXh0L2Rpc3QvYnVpbGQvdGVtcGxhdGVzL2hlbHBlcnNcIjtcbi8vIEltcG9ydCB0aGUgYXBwIGFuZCBkb2N1bWVudCBtb2R1bGVzLlxuaW1wb3J0IERvY3VtZW50IGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2RvY3VtZW50XCI7XG5pbXBvcnQgQXBwIGZyb20gXCJwcml2YXRlLW5leHQtcGFnZXMvX2FwcFwiO1xuLy8gSW1wb3J0IHRoZSB1c2VybGFuZCBjb2RlLlxuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi4vcGFnZXNcXFxcbG9naW4uanNcIjtcbi8vIFJlLWV4cG9ydCB0aGUgY29tcG9uZW50IChzaG91bGQgYmUgdGhlIGRlZmF1bHQgZXhwb3J0KS5cbmV4cG9ydCBkZWZhdWx0IGhvaXN0KHVzZXJsYW5kLCBcImRlZmF1bHRcIik7XG4vLyBSZS1leHBvcnQgbWV0aG9kcy5cbmV4cG9ydCBjb25zdCBnZXRTdGF0aWNQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcImdldFN0YXRpY1Byb3BzXCIpO1xuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U3RhdGljUGF0aHNcIik7XG5leHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsIFwiZ2V0U2VydmVyU2lkZVByb3BzXCIpO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGhvaXN0KHVzZXJsYW5kLCBcImNvbmZpZ1wiKTtcbmV4cG9ydCBjb25zdCByZXBvcnRXZWJWaXRhbHMgPSBob2lzdCh1c2VybGFuZCwgXCJyZXBvcnRXZWJWaXRhbHNcIik7XG4vLyBSZS1leHBvcnQgbGVnYWN5IG1ldGhvZHMuXG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U3RhdGljUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgXCJ1bnN0YWJsZV9nZXRTdGF0aWNQcm9wc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTdGF0aWNQYXRocyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1BhdGhzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhcmFtcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFN0YXRpY1BhcmFtc1wiKTtcbmV4cG9ydCBjb25zdCB1bnN0YWJsZV9nZXRTZXJ2ZXJQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFNlcnZlclByb3BzXCIpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCBcInVuc3RhYmxlX2dldFNlcnZlclNpZGVQcm9wc1wiKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTLFxuICAgICAgICBwYWdlOiBcIi9sb2dpblwiLFxuICAgICAgICBwYXRobmFtZTogXCIvbG9naW5cIixcbiAgICAgICAgLy8gVGhlIGZvbGxvd2luZyBhcmVuJ3QgdXNlZCBpbiBwcm9kdWN0aW9uLlxuICAgICAgICBidW5kbGVQYXRoOiBcIlwiLFxuICAgICAgICBmaWxlbmFtZTogXCJcIlxuICAgIH0sXG4gICAgY29tcG9uZW50czoge1xuICAgICAgICBBcHAsXG4gICAgICAgIERvY3VtZW50XG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Flogin&preferredRegion=&absolutePagePath=.%2Fpages%5Clogin.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _MainNav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MainNav */ \"./components/MainNav.js\");\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainNav__WEBPACK_IMPORTED_MODULE_2__]);\n_MainNav__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// components/Layout.js\n\n\n\n\nconst Layout = ({ children })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MainNav__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\Layout.js\",\n                lineNumber: 9,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                style: {\n                    paddingTop: \"100px\"\n                },\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Container, {\n                    children: children\n                }, void 0, false, {\n                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\Layout.js\",\n                    lineNumber: 11,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\Layout.js\",\n                lineNumber: 10,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUEsdUJBQXVCOztBQUNHO0FBQ007QUFDWTtBQUU1QyxNQUFNRyxTQUFTLENBQUMsRUFBRUMsUUFBUSxFQUFFO0lBQzFCLHFCQUNFOzswQkFDRSw4REFBQ0gsZ0RBQU9BOzs7OzswQkFDUiw4REFBQ0k7Z0JBQUlDLE9BQU87b0JBQUVDLFlBQVk7Z0JBQVE7MEJBQ2hDLDRFQUFDTCx1RkFBU0E7OEJBQ1BFOzs7Ozs7Ozs7Ozs7O0FBS1g7QUFFQSxpRUFBZUQsTUFBTUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL2NvbXBvbmVudHMvTGF5b3V0LmpzPzUxNWMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gY29tcG9uZW50cy9MYXlvdXQuanNcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IE1haW5OYXYgZnJvbSAnLi9NYWluTmF2JztcclxuaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSAncmVhY3QtYm9vdHN0cmFwJztcclxuXHJcbmNvbnN0IExheW91dCA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPE1haW5OYXYgLz5cclxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nVG9wOiAnMTAwcHgnIH19PlxyXG4gICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExheW91dDtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiTWFpbk5hdiIsIkNvbnRhaW5lciIsIkxheW91dCIsImNoaWxkcmVuIiwiZGl2Iiwic3R5bGUiLCJwYWRkaW5nVG9wIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/MainNav.js":
/*!*******************************!*\
  !*** ./components/MainNav.js ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! __barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!react-bootstrap */ \"__barrel_optimize__?names=Button,Container,Form,Nav,NavDropdown,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../store */ \"./store.js\");\n/* harmony import */ var _lib_userData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/lib/userData */ \"./lib/userData.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_4__, _store__WEBPACK_IMPORTED_MODULE_5__, _lib_userData__WEBPACK_IMPORTED_MODULE_6__]);\n([jotai__WEBPACK_IMPORTED_MODULE_4__, _store__WEBPACK_IMPORTED_MODULE_5__, _lib_userData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n // Import the addToHistory function\nconst MainNav = ()=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();\n    const [searchField, setSearchField] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_4__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_5__.searchHistoryAtom);\n    const handleSearchSubmit = async (event)=>{\n        event.preventDefault();\n        const queryString = `title=true&q=${searchField}`;\n        // Add the query to the history using the API\n        setSearchHistory(await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_6__.addToHistory)(queryString));\n        // Navigate to the artwork page\n        router.push(`/artwork?${queryString}`);\n        // Collapse the navbar\n        setIsExpanded(false);\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar, {\n        expanded: isExpanded,\n        expand: \"lg\",\n        className: \"navbar-dark bg-primary fixed-top\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Container, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Brand, {\n                    children: \"Krutin Bharatbhai Polra\"\n                }, void 0, false, {\n                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                    lineNumber: 33,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Toggle, {\n                    \"aria-controls\": \"main-navbar-nav\",\n                    onClick: ()=>setIsExpanded(!isExpanded)\n                }, void 0, false, {\n                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                    lineNumber: 34,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Collapse, {\n                    id: \"main-navbar-nav\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav, {\n                            className: \"me-auto\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                    legacyBehavior: true,\n                                    href: \"/\",\n                                    passHref: true,\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Home\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 38,\n                                        columnNumber: 15\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 37,\n                                    columnNumber: 13\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                    legacyBehavior: true,\n                                    href: \"/search\",\n                                    passHref: true,\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                                        onClick: ()=>setIsExpanded(false),\n                                        children: \"Advanced Search\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 41,\n                                        columnNumber: 15\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 40,\n                                    columnNumber: 13\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                            lineNumber: 36,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Form, {\n                            className: \"d-flex me-2\",\n                            onSubmit: handleSearchSubmit,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Form.Control, {\n                                    type: \"search\",\n                                    placeholder: \"Search\",\n                                    className: \"me-2\",\n                                    \"aria-label\": \"Search\",\n                                    value: searchField,\n                                    onChange: (e)=>setSearchField(e.target.value)\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 45,\n                                    columnNumber: 13\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Button, {\n                                    variant: \"outline-light\",\n                                    type: \"submit\",\n                                    children: \"Search\"\n                                }, void 0, false, {\n                                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                    lineNumber: 53,\n                                    columnNumber: 13\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                            lineNumber: 44,\n                            columnNumber: 11\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav, {\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.NavDropdown, {\n                                title: \"User Name\",\n                                id: \"user-dropdown\",\n                                align: \"end\",\n                                onClick: ()=>setIsExpanded(false),\n                                children: [\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.NavDropdown.Item, {\n                                        as: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),\n                                        href: \"/favourites\",\n                                        passHref: true,\n                                        children: \"Favourites\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 57,\n                                        columnNumber: 15\n                                    }, undefined),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Button_Container_Form_Nav_NavDropdown_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.NavDropdown.Item, {\n                                        as: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),\n                                        href: \"/history\",\n                                        passHref: true,\n                                        children: \"History\"\n                                    }, void 0, false, {\n                                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                        lineNumber: 58,\n                                        columnNumber: 15\n                                    }, undefined)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                                lineNumber: 56,\n                                columnNumber: 13\n                            }, undefined)\n                        }, void 0, false, {\n                            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                            lineNumber: 55,\n                            columnNumber: 11\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n                    lineNumber: 35,\n                    columnNumber: 9\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n            lineNumber: 32,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\components\\\\MainNav.js\",\n        lineNumber: 31,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainNav);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL01haW5OYXYuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBd0M7QUFDNEM7QUFDdkQ7QUFDVztBQUNSO0FBQ2E7QUFDQyxDQUFDLG1DQUFtQztBQUVsRixNQUFNYSxVQUFVO0lBQ2QsTUFBTUMsU0FBU0wsc0RBQVNBO0lBQ3hCLE1BQU0sQ0FBQ00sYUFBYUMsZUFBZSxHQUFHZiwrQ0FBUUEsQ0FBQztJQUMvQyxNQUFNLENBQUNnQixZQUFZQyxjQUFjLEdBQUdqQiwrQ0FBUUEsQ0FBQztJQUM3QyxNQUFNLENBQUNrQixlQUFlQyxpQkFBaUIsR0FBR1YsOENBQU9BLENBQUNDLHFEQUFpQkE7SUFFbkUsTUFBTVUscUJBQXFCLE9BQU9DO1FBQ2hDQSxNQUFNQyxjQUFjO1FBRXBCLE1BQU1DLGNBQWMsQ0FBQyxhQUFhLEVBQUVULFlBQVksQ0FBQztRQUVqRCw2Q0FBNkM7UUFDN0NLLGlCQUFpQixNQUFNUiwyREFBWUEsQ0FBQ1k7UUFFcEMsK0JBQStCO1FBQy9CVixPQUFPVyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUVELFlBQVksQ0FBQztRQUVyQyxzQkFBc0I7UUFDdEJOLGNBQWM7SUFDaEI7SUFFQSxxQkFDRSw4REFBQ2hCLHVIQUFNQTtRQUFDd0IsVUFBVVQ7UUFBWVUsUUFBTztRQUFLQyxXQUFVO2tCQUNsRCw0RUFBQ3RCLDBIQUFTQTs7OEJBQ1IsOERBQUNKLHVIQUFNQSxDQUFDMkIsS0FBSzs4QkFBQzs7Ozs7OzhCQUNkLDhEQUFDM0IsdUhBQU1BLENBQUM0QixNQUFNO29CQUFDQyxpQkFBYztvQkFBa0JDLFNBQVMsSUFBTWQsY0FBYyxDQUFDRDs7Ozs7OzhCQUM3RSw4REFBQ2YsdUhBQU1BLENBQUMrQixRQUFRO29CQUFDQyxJQUFHOztzQ0FDbEIsOERBQUMvQixvSEFBR0E7NEJBQUN5QixXQUFVOzs4Q0FDYiw4REFBQ3BCLGtEQUFJQTtvQ0FBQzJCLGNBQWM7b0NBQUNDLE1BQUs7b0NBQUlDLFFBQVE7OENBQ3BDLDRFQUFDbEMsb0hBQUdBLENBQUNLLElBQUk7d0NBQUN3QixTQUFTLElBQU1kLGNBQWM7a0RBQVE7Ozs7Ozs7Ozs7OzhDQUVqRCw4REFBQ1Ysa0RBQUlBO29DQUFDMkIsY0FBYztvQ0FBQ0MsTUFBSztvQ0FBVUMsUUFBUTs4Q0FDMUMsNEVBQUNsQyxvSEFBR0EsQ0FBQ0ssSUFBSTt3Q0FBQ3dCLFNBQVMsSUFBTWQsY0FBYztrREFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7c0NBR25ELDhEQUFDZCxxSEFBSUE7NEJBQUN3QixXQUFVOzRCQUFjVSxVQUFVakI7OzhDQUN0Qyw4REFBQ2pCLHFIQUFJQSxDQUFDbUMsT0FBTztvQ0FDWEMsTUFBSztvQ0FDTEMsYUFBWTtvQ0FDWmIsV0FBVTtvQ0FDVmMsY0FBVztvQ0FDWEMsT0FBTzVCO29DQUNQNkIsVUFBVSxDQUFDQyxJQUFNN0IsZUFBZTZCLEVBQUVDLE1BQU0sQ0FBQ0gsS0FBSzs7Ozs7OzhDQUVoRCw4REFBQ3RDLHVIQUFNQTtvQ0FBQzBDLFNBQVE7b0NBQWdCUCxNQUFLOzhDQUFTOzs7Ozs7Ozs7Ozs7c0NBRWhELDhEQUFDckMsb0hBQUdBO3NDQUNGLDRFQUFDSSw0SEFBV0E7Z0NBQUN5QyxPQUFNO2dDQUFZZCxJQUFHO2dDQUFnQmUsT0FBTTtnQ0FBTWpCLFNBQVMsSUFBTWQsY0FBYzs7a0RBQ3pGLDhEQUFDWCw0SEFBV0EsQ0FBQzJDLElBQUk7d0NBQUNDLElBQUkzQyxrREFBSUE7d0NBQUU0QixNQUFLO3dDQUFjQyxRQUFRO2tEQUFDOzs7Ozs7a0RBQ3hELDhEQUFDOUIsNEhBQVdBLENBQUMyQyxJQUFJO3dDQUFDQyxJQUFJM0Msa0RBQUlBO3dDQUFFNEIsTUFBSzt3Q0FBV0MsUUFBUTtrREFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU9uRTtBQUVBLGlFQUFleEIsT0FBT0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL2NvbXBvbmVudHMvTWFpbk5hdi5qcz9lZjg5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTmF2YmFyLCBOYXYsIEZvcm0sIEJ1dHRvbiwgQ29udGFpbmVyLCBOYXZEcm9wZG93biB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHsgdXNlQXRvbSB9IGZyb20gJ2pvdGFpJztcclxuaW1wb3J0IHsgc2VhcmNoSGlzdG9yeUF0b20gfSBmcm9tICcuLi9zdG9yZSc7XHJcbmltcG9ydCB7IGFkZFRvSGlzdG9yeSB9IGZyb20gJ0AvbGliL3VzZXJEYXRhJzsgLy8gSW1wb3J0IHRoZSBhZGRUb0hpc3RvcnkgZnVuY3Rpb25cclxuXHJcbmNvbnN0IE1haW5OYXYgPSAoKSA9PiB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgW3NlYXJjaEZpZWxkLCBzZXRTZWFyY2hGaWVsZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2lzRXhwYW5kZWQsIHNldElzRXhwYW5kZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hIaXN0b3J5LCBzZXRTZWFyY2hIaXN0b3J5XSA9IHVzZUF0b20oc2VhcmNoSGlzdG9yeUF0b20pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWFyY2hTdWJtaXQgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgY29uc3QgcXVlcnlTdHJpbmcgPSBgdGl0bGU9dHJ1ZSZxPSR7c2VhcmNoRmllbGR9YDtcclxuICAgIFxyXG4gICAgLy8gQWRkIHRoZSBxdWVyeSB0byB0aGUgaGlzdG9yeSB1c2luZyB0aGUgQVBJXHJcbiAgICBzZXRTZWFyY2hIaXN0b3J5KGF3YWl0IGFkZFRvSGlzdG9yeShxdWVyeVN0cmluZykpO1xyXG5cclxuICAgIC8vIE5hdmlnYXRlIHRvIHRoZSBhcnR3b3JrIHBhZ2VcclxuICAgIHJvdXRlci5wdXNoKGAvYXJ0d29yaz8ke3F1ZXJ5U3RyaW5nfWApO1xyXG5cclxuICAgIC8vIENvbGxhcHNlIHRoZSBuYXZiYXJcclxuICAgIHNldElzRXhwYW5kZWQoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TmF2YmFyIGV4cGFuZGVkPXtpc0V4cGFuZGVkfSBleHBhbmQ9XCJsZ1wiIGNsYXNzTmFtZT1cIm5hdmJhci1kYXJrIGJnLXByaW1hcnkgZml4ZWQtdG9wXCI+XHJcbiAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgPE5hdmJhci5CcmFuZD5LcnV0aW4gQmhhcmF0YmhhaSBQb2xyYTwvTmF2YmFyLkJyYW5kPlxyXG4gICAgICAgIDxOYXZiYXIuVG9nZ2xlIGFyaWEtY29udHJvbHM9XCJtYWluLW5hdmJhci1uYXZcIiBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKCFpc0V4cGFuZGVkKX0gLz5cclxuICAgICAgICA8TmF2YmFyLkNvbGxhcHNlIGlkPVwibWFpbi1uYXZiYXItbmF2XCI+XHJcbiAgICAgICAgICA8TmF2IGNsYXNzTmFtZT1cIm1lLWF1dG9cIj5cclxuICAgICAgICAgICAgPExpbmsgbGVnYWN5QmVoYXZpb3IgaHJlZj1cIi9cIiBwYXNzSHJlZj5cclxuICAgICAgICAgICAgICA8TmF2Lkxpbmsgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9PkhvbWU8L05hdi5MaW5rPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgIDxMaW5rIGxlZ2FjeUJlaGF2aW9yIGhyZWY9XCIvc2VhcmNoXCIgcGFzc0hyZWY+XHJcbiAgICAgICAgICAgICAgPE5hdi5MaW5rIG9uQ2xpY2s9eygpID0+IHNldElzRXhwYW5kZWQoZmFsc2UpfT5BZHZhbmNlZCBTZWFyY2g8L05hdi5MaW5rPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L05hdj5cclxuICAgICAgICAgIDxGb3JtIGNsYXNzTmFtZT1cImQtZmxleCBtZS0yXCIgb25TdWJtaXQ9e2hhbmRsZVNlYXJjaFN1Ym1pdH0+XHJcbiAgICAgICAgICAgIDxGb3JtLkNvbnRyb2xcclxuICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWUtMlwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNlYXJjaFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaEZpZWxkfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoRmllbGQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lLWxpZ2h0XCIgdHlwZT1cInN1Ym1pdFwiPlNlYXJjaDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgICAgPE5hdj5cclxuICAgICAgICAgICAgPE5hdkRyb3Bkb3duIHRpdGxlPVwiVXNlciBOYW1lXCIgaWQ9XCJ1c2VyLWRyb3Bkb3duXCIgYWxpZ249XCJlbmRcIiBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgPE5hdkRyb3Bkb3duLkl0ZW0gYXM9e0xpbmt9IGhyZWY9XCIvZmF2b3VyaXRlc1wiIHBhc3NIcmVmPkZhdm91cml0ZXM8L05hdkRyb3Bkb3duLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPE5hdkRyb3Bkb3duLkl0ZW0gYXM9e0xpbmt9IGhyZWY9XCIvaGlzdG9yeVwiIHBhc3NIcmVmPkhpc3Rvcnk8L05hdkRyb3Bkb3duLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvTmF2RHJvcGRvd24+XHJcbiAgICAgICAgICA8L05hdj5cclxuICAgICAgICA8L05hdmJhci5Db2xsYXBzZT5cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICA8L05hdmJhcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWFpbk5hdjtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJOYXZiYXIiLCJOYXYiLCJGb3JtIiwiQnV0dG9uIiwiQ29udGFpbmVyIiwiTmF2RHJvcGRvd24iLCJMaW5rIiwidXNlUm91dGVyIiwidXNlQXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIiwiYWRkVG9IaXN0b3J5IiwiTWFpbk5hdiIsInJvdXRlciIsInNlYXJjaEZpZWxkIiwic2V0U2VhcmNoRmllbGQiLCJpc0V4cGFuZGVkIiwic2V0SXNFeHBhbmRlZCIsInNlYXJjaEhpc3RvcnkiLCJzZXRTZWFyY2hIaXN0b3J5IiwiaGFuZGxlU2VhcmNoU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInF1ZXJ5U3RyaW5nIiwicHVzaCIsImV4cGFuZGVkIiwiZXhwYW5kIiwiY2xhc3NOYW1lIiwiQnJhbmQiLCJUb2dnbGUiLCJhcmlhLWNvbnRyb2xzIiwib25DbGljayIsIkNvbGxhcHNlIiwiaWQiLCJsZWdhY3lCZWhhdmlvciIsImhyZWYiLCJwYXNzSHJlZiIsIm9uU3VibWl0IiwiQ29udHJvbCIsInR5cGUiLCJwbGFjZWhvbGRlciIsImFyaWEtbGFiZWwiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsInZhcmlhbnQiLCJ0aXRsZSIsImFsaWduIiwiSXRlbSIsImFzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/MainNav.js\n");

/***/ }),

/***/ "./components/RouteGuard.js":
/*!**********************************!*\
  !*** ./components/RouteGuard.js ***!
  \**********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RouteGuard)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _lib_authenticate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/lib/authenticate */ \"./lib/authenticate.js\");\n/* harmony import */ var _lib_userData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/lib/userData */ \"./lib/userData.js\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/store */ \"./store.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_3__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_4__, _lib_userData__WEBPACK_IMPORTED_MODULE_5__, _store__WEBPACK_IMPORTED_MODULE_6__]);\n([jotai__WEBPACK_IMPORTED_MODULE_3__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_4__, _lib_userData__WEBPACK_IMPORTED_MODULE_5__, _store__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\nconst PUBLIC_PATHS = [\n    \"/login\",\n    \"/\",\n    \"/_error\",\n    \"/register\"\n];\nfunction RouteGuard(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const [authorized, setAuthorized] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const [, setFavouritesList] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_6__.favouritesAtom);\n    const [, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_6__.searchHistoryAtom);\n    const updateAtoms = async ()=>{\n        setFavouritesList(await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_5__.getFavourites)());\n        setSearchHistory(await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_5__.getHistory)());\n    };\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        // Initial auth check and atom update\n        authCheck(router.pathname);\n        if ((0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_4__.isAuthenticated)()) updateAtoms();\n        // On route change, perform auth check\n        router.events.on(\"routeChangeComplete\", authCheck);\n        // Cleanup the router event listener\n        return ()=>{\n            router.events.off(\"routeChangeComplete\", authCheck);\n        };\n    }, []);\n    const authCheck = (url)=>{\n        const path = url.split(\"?\")[0];\n        if (!(0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_4__.isAuthenticated)() && !PUBLIC_PATHS.includes(path)) {\n            setAuthorized(false);\n            router.push(\"/login\");\n        } else {\n            setAuthorized(true);\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: authorized && props.children\n    }, void 0, false);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1JvdXRlR3VhcmQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXdDO0FBQ0k7QUFDWjtBQUNxQjtBQUNNO0FBQ0M7QUFFNUQsTUFBTVMsZUFBZTtJQUFDO0lBQVU7SUFBSztJQUFXO0NBQVk7QUFFN0MsU0FBU0MsV0FBV0MsS0FBSztJQUN0QyxNQUFNQyxTQUFTWixzREFBU0E7SUFDeEIsTUFBTSxDQUFDYSxZQUFZQyxjQUFjLEdBQUdiLCtDQUFRQSxDQUFDO0lBQzdDLE1BQU0sR0FBR2Msa0JBQWtCLEdBQUdaLDhDQUFPQSxDQUFDSSxrREFBY0E7SUFDcEQsTUFBTSxHQUFHUyxpQkFBaUIsR0FBR2IsOENBQU9BLENBQUNLLHFEQUFpQkE7SUFFdEQsTUFBTVMsY0FBYztRQUNsQkYsa0JBQWtCLE1BQU1WLDREQUFhQTtRQUNyQ1csaUJBQWlCLE1BQU1WLHlEQUFVQTtJQUNuQztJQUVBSixnREFBU0EsQ0FBQztRQUNSLHFDQUFxQztRQUNyQ2dCLFVBQVVOLE9BQU9PLFFBQVE7UUFDekIsSUFBSWYsa0VBQWVBLElBQUlhO1FBRXZCLHNDQUFzQztRQUN0Q0wsT0FBT1EsTUFBTSxDQUFDQyxFQUFFLENBQUMsdUJBQXVCSDtRQUV4QyxvQ0FBb0M7UUFDcEMsT0FBTztZQUNMTixPQUFPUSxNQUFNLENBQUNFLEdBQUcsQ0FBQyx1QkFBdUJKO1FBQzNDO0lBQ0YsR0FBRyxFQUFFO0lBRUwsTUFBTUEsWUFBWSxDQUFDSztRQUNqQixNQUFNQyxPQUFPRCxJQUFJRSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDOUIsSUFBSSxDQUFDckIsa0VBQWVBLE1BQU0sQ0FBQ0ssYUFBYWlCLFFBQVEsQ0FBQ0YsT0FBTztZQUN0RFYsY0FBYztZQUNkRixPQUFPZSxJQUFJLENBQUM7UUFDZCxPQUFPO1lBQ0xiLGNBQWM7UUFDaEI7SUFDRjtJQUVBLHFCQUFPO2tCQUFHRCxjQUFjRixNQUFNaUIsUUFBUTs7QUFDeEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9jb21wb25lbnRzL1JvdXRlR3VhcmQuanM/MWQ1MyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUF0b20gfSBmcm9tICdqb3RhaSc7XHJcbmltcG9ydCB7IGlzQXV0aGVudGljYXRlZCB9IGZyb20gJ0AvbGliL2F1dGhlbnRpY2F0ZSc7XHJcbmltcG9ydCB7IGdldEZhdm91cml0ZXMsIGdldEhpc3RvcnkgfSBmcm9tICdAL2xpYi91c2VyRGF0YSc7XHJcbmltcG9ydCB7IGZhdm91cml0ZXNBdG9tLCBzZWFyY2hIaXN0b3J5QXRvbSB9IGZyb20gJ0Avc3RvcmUnO1xyXG5cclxuY29uc3QgUFVCTElDX1BBVEhTID0gWycvbG9naW4nLCAnLycsICcvX2Vycm9yJywgJy9yZWdpc3RlciddO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm91dGVHdWFyZChwcm9wcykge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IFthdXRob3JpemVkLCBzZXRBdXRob3JpemVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbLCBzZXRGYXZvdXJpdGVzTGlzdF0gPSB1c2VBdG9tKGZhdm91cml0ZXNBdG9tKTtcclxuICBjb25zdCBbLCBzZXRTZWFyY2hIaXN0b3J5XSA9IHVzZUF0b20oc2VhcmNoSGlzdG9yeUF0b20pO1xyXG5cclxuICBjb25zdCB1cGRhdGVBdG9tcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldEZhdm91cml0ZXNMaXN0KGF3YWl0IGdldEZhdm91cml0ZXMoKSk7XHJcbiAgICBzZXRTZWFyY2hIaXN0b3J5KGF3YWl0IGdldEhpc3RvcnkoKSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIEluaXRpYWwgYXV0aCBjaGVjayBhbmQgYXRvbSB1cGRhdGVcclxuICAgIGF1dGhDaGVjayhyb3V0ZXIucGF0aG5hbWUpO1xyXG4gICAgaWYgKGlzQXV0aGVudGljYXRlZCgpKSB1cGRhdGVBdG9tcygpO1xyXG5cclxuICAgIC8vIE9uIHJvdXRlIGNoYW5nZSwgcGVyZm9ybSBhdXRoIGNoZWNrXHJcbiAgICByb3V0ZXIuZXZlbnRzLm9uKCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgYXV0aENoZWNrKTtcclxuXHJcbiAgICAvLyBDbGVhbnVwIHRoZSByb3V0ZXIgZXZlbnQgbGlzdGVuZXJcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHJvdXRlci5ldmVudHMub2ZmKCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgYXV0aENoZWNrKTtcclxuICAgIH07XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBhdXRoQ2hlY2sgPSAodXJsKSA9PiB7XHJcbiAgICBjb25zdCBwYXRoID0gdXJsLnNwbGl0KCc/JylbMF07XHJcbiAgICBpZiAoIWlzQXV0aGVudGljYXRlZCgpICYmICFQVUJMSUNfUEFUSFMuaW5jbHVkZXMocGF0aCkpIHtcclxuICAgICAgc2V0QXV0aG9yaXplZChmYWxzZSk7XHJcbiAgICAgIHJvdXRlci5wdXNoKCcvbG9naW4nKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEF1dGhvcml6ZWQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIDw+e2F1dGhvcml6ZWQgJiYgcHJvcHMuY2hpbGRyZW59PC8+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJ1c2VSb3V0ZXIiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUF0b20iLCJpc0F1dGhlbnRpY2F0ZWQiLCJnZXRGYXZvdXJpdGVzIiwiZ2V0SGlzdG9yeSIsImZhdm91cml0ZXNBdG9tIiwic2VhcmNoSGlzdG9yeUF0b20iLCJQVUJMSUNfUEFUSFMiLCJSb3V0ZUd1YXJkIiwicHJvcHMiLCJyb3V0ZXIiLCJhdXRob3JpemVkIiwic2V0QXV0aG9yaXplZCIsInNldEZhdm91cml0ZXNMaXN0Iiwic2V0U2VhcmNoSGlzdG9yeSIsInVwZGF0ZUF0b21zIiwiYXV0aENoZWNrIiwicGF0aG5hbWUiLCJldmVudHMiLCJvbiIsIm9mZiIsInVybCIsInBhdGgiLCJzcGxpdCIsImluY2x1ZGVzIiwicHVzaCIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/RouteGuard.js\n");

/***/ }),

/***/ "./lib/authenticate.js":
/*!*****************************!*\
  !*** ./lib/authenticate.js ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authenticateUser: () => (/* binding */ authenticateUser),\n/* harmony export */   getToken: () => (/* binding */ getToken),\n/* harmony export */   isAuthenticated: () => (/* binding */ isAuthenticated),\n/* harmony export */   readToken: () => (/* binding */ readToken),\n/* harmony export */   registerUser: () => (/* binding */ registerUser),\n/* harmony export */   removeToken: () => (/* binding */ removeToken),\n/* harmony export */   setToken: () => (/* binding */ setToken)\n/* harmony export */ });\n/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jwt-decode */ \"jwt-decode\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jwt_decode__WEBPACK_IMPORTED_MODULE_0__]);\njwt_decode__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nfunction setToken(token) {\n    localStorage.setItem(\"access_token\", token);\n}\nfunction getToken() {\n    try {\n        return localStorage.getItem(\"access_token\");\n    } catch (err) {\n        return null;\n    }\n}\nfunction removeToken() {\n    localStorage.removeItem(\"access_token\");\n}\nfunction readToken() {\n    try {\n        const token = getToken();\n        const decoded = (0,jwt_decode__WEBPACK_IMPORTED_MODULE_0__[\"default\"])(token);\n        return decoded;\n    } catch (err) {\n        return null;\n    }\n}\nfunction isAuthenticated() {\n    const token = readToken();\n    return token ? true : false;\n}\nasync function authenticateUser(userName, password) {\n    const res = await fetch(`${\"https://user-api-neon-five.vercel.app/api/user\"}/login`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\"\n        },\n        body: JSON.stringify({\n            userName,\n            password\n        })\n    });\n    if (res.status === 200) {\n        const { token } = await res.json();\n        setToken(token);\n        return true;\n    } else {\n        const errorData = await res.json();\n        throw new Error(errorData.message);\n    }\n}\nasync function registerUser(userName, password, password2) {\n    const res = await fetch(`${\"https://user-api-neon-five.vercel.app/api/user\"}/register`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\"\n        },\n        body: JSON.stringify({\n            userName,\n            password,\n            password2\n        })\n    });\n    if (res.ok) {\n        return true; // Registration successful\n    } else {\n        const errorData = await res.json();\n        throw new Error(errorData.message);\n    }\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvYXV0aGVudGljYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQW1DO0FBRTVCLFNBQVNDLFNBQVNDLEtBQUs7SUFDNUJDLGFBQWFDLE9BQU8sQ0FBQyxnQkFBZ0JGO0FBQ3ZDO0FBRU8sU0FBU0c7SUFDZCxJQUFJO1FBQ0YsT0FBT0YsYUFBYUcsT0FBTyxDQUFDO0lBQzlCLEVBQUUsT0FBT0MsS0FBSztRQUNaLE9BQU87SUFDVDtBQUNGO0FBRU8sU0FBU0M7SUFDZEwsYUFBYU0sVUFBVSxDQUFDO0FBQzFCO0FBRU8sU0FBU0M7SUFDZCxJQUFJO1FBQ0YsTUFBTVIsUUFBUUc7UUFDZCxNQUFNTSxVQUFVWCxzREFBU0EsQ0FBQ0U7UUFDMUIsT0FBT1M7SUFDVCxFQUFFLE9BQU9KLEtBQUs7UUFDWixPQUFPO0lBQ1Q7QUFDRjtBQUVPLFNBQVNLO0lBQ2QsTUFBTVYsUUFBUVE7SUFDZCxPQUFPUixRQUFRLE9BQU87QUFDeEI7QUFFTyxlQUFlVyxpQkFBaUJDLFFBQVEsRUFBRUMsUUFBUTtJQUN2RCxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sQ0FBQyxFQUFFQyxnREFBK0IsQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNsRUcsUUFBUTtRQUNSQyxTQUFTO1lBQUUsZ0JBQWdCO1FBQW1CO1FBQzlDQyxNQUFNQyxLQUFLQyxTQUFTLENBQUM7WUFBRVg7WUFBVUM7UUFBUztJQUM1QztJQUVBLElBQUlDLElBQUlVLE1BQU0sS0FBSyxLQUFLO1FBQ3RCLE1BQU0sRUFBRXhCLEtBQUssRUFBRSxHQUFHLE1BQU1jLElBQUlXLElBQUk7UUFDaEMxQixTQUFTQztRQUNULE9BQU87SUFDVCxPQUFPO1FBQ0wsTUFBTTBCLFlBQVksTUFBTVosSUFBSVcsSUFBSTtRQUNoQyxNQUFNLElBQUlFLE1BQU1ELFVBQVVFLE9BQU87SUFDbkM7QUFDRjtBQUVPLGVBQWVDLGFBQWFqQixRQUFRLEVBQUVDLFFBQVEsRUFBRWlCLFNBQVM7SUFDOUQsTUFBTWhCLE1BQU0sTUFBTUMsTUFBTSxDQUFDLEVBQUVDLGdEQUErQixDQUFDLFNBQVMsQ0FBQyxFQUFFO1FBQ3JFRyxRQUFRO1FBQ1JDLFNBQVM7WUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUNDLE1BQU1DLEtBQUtDLFNBQVMsQ0FBQztZQUFFWDtZQUFVQztZQUFVaUI7UUFBVTtJQUN2RDtJQUVBLElBQUloQixJQUFJaUIsRUFBRSxFQUFFO1FBQ1IsT0FBTyxNQUFNLDBCQUEwQjtJQUMzQyxPQUFPO1FBQ0gsTUFBTUwsWUFBWSxNQUFNWixJQUFJVyxJQUFJO1FBQ2hDLE1BQU0sSUFBSUUsTUFBTUQsVUFBVUUsT0FBTztJQUNyQztBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vbGliL2F1dGhlbnRpY2F0ZS5qcz9kMWRkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBqd3REZWNvZGUgZnJvbSAnand0LWRlY29kZSc7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0VG9rZW4odG9rZW4pIHtcclxuICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnYWNjZXNzX3Rva2VuJywgdG9rZW4pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZ2V0VG9rZW4oKSB7XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnYWNjZXNzX3Rva2VuJyk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVUb2tlbigpIHtcclxuICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnYWNjZXNzX3Rva2VuJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZWFkVG9rZW4oKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcclxuICAgIGNvbnN0IGRlY29kZWQgPSBqd3REZWNvZGUodG9rZW4pO1xyXG4gICAgcmV0dXJuIGRlY29kZWQ7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpc0F1dGhlbnRpY2F0ZWQoKSB7XHJcbiAgY29uc3QgdG9rZW4gPSByZWFkVG9rZW4oKTtcclxuICByZXR1cm4gdG9rZW4gPyB0cnVlIDogZmFsc2U7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhdXRoZW50aWNhdGVVc2VyKHVzZXJOYW1lLCBwYXNzd29yZCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9L2xvZ2luYCwge1xyXG4gICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlck5hbWUsIHBhc3N3b3JkIH0pLFxyXG4gIH0pO1xyXG5cclxuICBpZiAocmVzLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICBjb25zdCB7IHRva2VuIH0gPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgc2V0VG9rZW4odG9rZW4pO1xyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNvbnN0IGVycm9yRGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoZXJyb3JEYXRhLm1lc3NhZ2UpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZ2lzdGVyVXNlcih1c2VyTmFtZSwgcGFzc3dvcmQsIHBhc3N3b3JkMikge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9L3JlZ2lzdGVyYCwge1xyXG4gICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlck5hbWUsIHBhc3N3b3JkLCBwYXNzd29yZDIgfSksXHJcbiAgfSk7XHJcblxyXG4gIGlmIChyZXMub2spIHtcclxuICAgICAgcmV0dXJuIHRydWU7IC8vIFJlZ2lzdHJhdGlvbiBzdWNjZXNzZnVsXHJcbiAgfSBlbHNlIHtcclxuICAgICAgY29uc3QgZXJyb3JEYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKGVycm9yRGF0YS5tZXNzYWdlKTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbImp3dERlY29kZSIsInNldFRva2VuIiwidG9rZW4iLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiZ2V0VG9rZW4iLCJnZXRJdGVtIiwiZXJyIiwicmVtb3ZlVG9rZW4iLCJyZW1vdmVJdGVtIiwicmVhZFRva2VuIiwiZGVjb2RlZCIsImlzQXV0aGVudGljYXRlZCIsImF1dGhlbnRpY2F0ZVVzZXIiLCJ1c2VyTmFtZSIsInBhc3N3b3JkIiwicmVzIiwiZmV0Y2giLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfQVBJX1VSTCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsInN0YXR1cyIsImpzb24iLCJlcnJvckRhdGEiLCJFcnJvciIsIm1lc3NhZ2UiLCJyZWdpc3RlclVzZXIiLCJwYXNzd29yZDIiLCJvayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./lib/authenticate.js\n");

/***/ }),

/***/ "./lib/userData.js":
/*!*************************!*\
  !*** ./lib/userData.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   addToFavourites: () => (/* binding */ addToFavourites),\n/* harmony export */   addToHistory: () => (/* binding */ addToHistory),\n/* harmony export */   getFavourites: () => (/* binding */ getFavourites),\n/* harmony export */   getHistory: () => (/* binding */ getHistory),\n/* harmony export */   removeFromFavourites: () => (/* binding */ removeFromFavourites),\n/* harmony export */   removeFromHistory: () => (/* binding */ removeFromHistory)\n/* harmony export */ });\n/* harmony import */ var _authenticate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authenticate */ \"./lib/authenticate.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_authenticate__WEBPACK_IMPORTED_MODULE_0__]);\n_authenticate__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nasync function makeRequest(endpoint, method = \"GET\", body = null) {\n    const token = (0,_authenticate__WEBPACK_IMPORTED_MODULE_0__.getToken)();\n    const res = await fetch(`${\"https://user-api-neon-five.vercel.app/api/user\"}/${endpoint}`, {\n        method,\n        headers: {\n            \"Content-Type\": \"application/json\",\n            Authorization: `JWT ${token}`\n        },\n        body: body ? JSON.stringify(body) : null\n    });\n    if (res.status === 200) {\n        return await res.json();\n    } else {\n        return [];\n    }\n}\nasync function addToFavourites(id) {\n    return await makeRequest(`favourites/${id}`, \"PUT\");\n}\nasync function removeFromFavourites(id) {\n    return await makeRequest(`favourites/${id}`, \"DELETE\");\n}\nasync function getFavourites() {\n    return await makeRequest(`favourites`);\n}\nasync function addToHistory(id) {\n    return await makeRequest(`history/${id}`, \"PUT\");\n}\nasync function removeFromHistory(id) {\n    return await makeRequest(`history/${id}`, \"DELETE\");\n}\nasync function getHistory() {\n    return await makeRequest(`history`);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvdXNlckRhdGEuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUEwQztBQUUxQyxlQUFlQyxZQUFZQyxRQUFRLEVBQUVDLFNBQVMsS0FBSyxFQUFFQyxPQUFPLElBQUk7SUFDOUQsTUFBTUMsUUFBUUwsdURBQVFBO0lBQ3RCLE1BQU1NLE1BQU0sTUFBTUMsTUFBTSxDQUFDLEVBQUVDLGdEQUErQixDQUFDLENBQUMsRUFBRU4sU0FBUyxDQUFDLEVBQUU7UUFDeEVDO1FBQ0FRLFNBQVM7WUFDUCxnQkFBZ0I7WUFDaEJDLGVBQWUsQ0FBQyxJQUFJLEVBQUVQLE1BQU0sQ0FBQztRQUMvQjtRQUNBRCxNQUFNQSxPQUFPUyxLQUFLQyxTQUFTLENBQUNWLFFBQVE7SUFDdEM7SUFFQSxJQUFJRSxJQUFJUyxNQUFNLEtBQUssS0FBSztRQUN0QixPQUFPLE1BQU1ULElBQUlVLElBQUk7SUFDdkIsT0FBTztRQUNMLE9BQU8sRUFBRTtJQUNYO0FBQ0Y7QUFFTyxlQUFlQyxnQkFBZ0JDLEVBQUU7SUFDdEMsT0FBTyxNQUFNakIsWUFBWSxDQUFDLFdBQVcsRUFBRWlCLEdBQUcsQ0FBQyxFQUFFO0FBQy9DO0FBRU8sZUFBZUMscUJBQXFCRCxFQUFFO0lBQzNDLE9BQU8sTUFBTWpCLFlBQVksQ0FBQyxXQUFXLEVBQUVpQixHQUFHLENBQUMsRUFBRTtBQUMvQztBQUVPLGVBQWVFO0lBQ3BCLE9BQU8sTUFBTW5CLFlBQVksQ0FBQyxVQUFVLENBQUM7QUFDdkM7QUFFTyxlQUFlb0IsYUFBYUgsRUFBRTtJQUNuQyxPQUFPLE1BQU1qQixZQUFZLENBQUMsUUFBUSxFQUFFaUIsR0FBRyxDQUFDLEVBQUU7QUFDNUM7QUFFTyxlQUFlSSxrQkFBa0JKLEVBQUU7SUFDeEMsT0FBTyxNQUFNakIsWUFBWSxDQUFDLFFBQVEsRUFBRWlCLEdBQUcsQ0FBQyxFQUFFO0FBQzVDO0FBRU8sZUFBZUs7SUFDcEIsT0FBTyxNQUFNdEIsWUFBWSxDQUFDLE9BQU8sQ0FBQztBQUNwQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL2xpYi91c2VyRGF0YS5qcz9jNGI3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldFRva2VuIH0gZnJvbSAnLi9hdXRoZW50aWNhdGUnO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gbWFrZVJlcXVlc3QoZW5kcG9pbnQsIG1ldGhvZCA9ICdHRVQnLCBib2R5ID0gbnVsbCkge1xyXG4gIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfS8ke2VuZHBvaW50fWAsIHtcclxuICAgIG1ldGhvZCxcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgQXV0aG9yaXphdGlvbjogYEpXVCAke3Rva2VufWAsXHJcbiAgICB9LFxyXG4gICAgYm9keTogYm9keSA/IEpTT04uc3RyaW5naWZ5KGJvZHkpIDogbnVsbCxcclxuICB9KTtcclxuXHJcbiAgaWYgKHJlcy5zdGF0dXMgPT09IDIwMCkge1xyXG4gICAgcmV0dXJuIGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiBbXTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0Zhdm91cml0ZXMoaWQpIHtcclxuICByZXR1cm4gYXdhaXQgbWFrZVJlcXVlc3QoYGZhdm91cml0ZXMvJHtpZH1gLCAnUFVUJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZW1vdmVGcm9tRmF2b3VyaXRlcyhpZCkge1xyXG4gIHJldHVybiBhd2FpdCBtYWtlUmVxdWVzdChgZmF2b3VyaXRlcy8ke2lkfWAsICdERUxFVEUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEZhdm91cml0ZXMoKSB7XHJcbiAgcmV0dXJuIGF3YWl0IG1ha2VSZXF1ZXN0KGBmYXZvdXJpdGVzYCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0hpc3RvcnkoaWQpIHtcclxuICByZXR1cm4gYXdhaXQgbWFrZVJlcXVlc3QoYGhpc3RvcnkvJHtpZH1gLCAnUFVUJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZW1vdmVGcm9tSGlzdG9yeShpZCkge1xyXG4gIHJldHVybiBhd2FpdCBtYWtlUmVxdWVzdChgaGlzdG9yeS8ke2lkfWAsICdERUxFVEUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEhpc3RvcnkoKSB7XHJcbiAgcmV0dXJuIGF3YWl0IG1ha2VSZXF1ZXN0KGBoaXN0b3J5YCk7XHJcbn1cclxuIl0sIm5hbWVzIjpbImdldFRva2VuIiwibWFrZVJlcXVlc3QiLCJlbmRwb2ludCIsIm1ldGhvZCIsImJvZHkiLCJ0b2tlbiIsInJlcyIsImZldGNoIiwicHJvY2VzcyIsImVudiIsIk5FWFRfUFVCTElDX0FQSV9VUkwiLCJoZWFkZXJzIiwiQXV0aG9yaXphdGlvbiIsIkpTT04iLCJzdHJpbmdpZnkiLCJzdGF0dXMiLCJqc29uIiwiYWRkVG9GYXZvdXJpdGVzIiwiaWQiLCJyZW1vdmVGcm9tRmF2b3VyaXRlcyIsImdldEZhdm91cml0ZXMiLCJhZGRUb0hpc3RvcnkiLCJyZW1vdmVGcm9tSGlzdG9yeSIsImdldEhpc3RvcnkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./lib/userData.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyApp)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ \"./node_modules/bootstrap/dist/css/bootstrap.min.css\");\n/* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swr */ \"swr\");\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/styles/bootstrap.min.css */ \"./styles/bootstrap.min.css\");\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _components_RouteGuard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/components/RouteGuard */ \"./components/RouteGuard.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__, _components_RouteGuard__WEBPACK_IMPORTED_MODULE_6__]);\n([_components_Layout__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__, _components_RouteGuard__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n// pages/_app.js\n\n\n\n\n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(swr__WEBPACK_IMPORTED_MODULE_4__.SWRConfig, {\n        value: {\n            fetcher: async (url)=>{\n                const res = await fetch(url);\n                if (!res.ok) {\n                    const error = new Error(\"An error occurred while fetching the data.\");\n                    error.info = await res.json();\n                    error.status = res.status;\n                    throw error;\n                }\n                return res.json();\n            }\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_RouteGuard__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_app.js\",\n                    lineNumber: 25,\n                    columnNumber: 11\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_app.js\",\n                lineNumber: 24,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_app.js\",\n            lineNumber: 23,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_app.js\",\n        lineNumber: 11,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGdCQUFnQjs7QUFDOEI7QUFDZjtBQUNXO0FBQ1Y7QUFDSTtBQUNhO0FBRWxDLFNBQVNHLE1BQU0sRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDcEQscUJBQ0UsOERBQUNKLDBDQUFTQTtRQUFDSyxPQUFPO1lBQ2hCQyxTQUFTLE9BQU9DO2dCQUNkLE1BQU1DLE1BQU0sTUFBTUMsTUFBTUY7Z0JBQ3hCLElBQUksQ0FBQ0MsSUFBSUUsRUFBRSxFQUFFO29CQUNYLE1BQU1DLFFBQVEsSUFBSUMsTUFBTTtvQkFDeEJELE1BQU1FLElBQUksR0FBRyxNQUFNTCxJQUFJTSxJQUFJO29CQUMzQkgsTUFBTUksTUFBTSxHQUFHUCxJQUFJTyxNQUFNO29CQUN6QixNQUFNSjtnQkFDUjtnQkFDQSxPQUFPSCxJQUFJTSxJQUFJO1lBQ2pCO1FBQ0Y7a0JBQ0UsNEVBQUNiLDhEQUFVQTtzQkFDVCw0RUFBQ0YsMERBQU1BOzBCQUNMLDRFQUFDSTtvQkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLbEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gcGFnZXMvX2FwcC5qc1xuaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL0xheW91dCc7XG5pbXBvcnQgeyBTV1JDb25maWcgfSBmcm9tICdzd3InO1xuaW1wb3J0ICdAL3N0eWxlcy9ib290c3RyYXAubWluLmNzcyc7XG5pbXBvcnQgUm91dGVHdWFyZCBmcm9tICdAL2NvbXBvbmVudHMvUm91dGVHdWFyZCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxTV1JDb25maWcgdmFsdWU9e3tcbiAgICAgIGZldGNoZXI6IGFzeW5jICh1cmwpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcbiAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgZmV0Y2hpbmcgdGhlIGRhdGEuJyk7XG4gICAgICAgICAgZXJyb3IuaW5mbyA9IGF3YWl0IHJlcy5qc29uKCk7XG4gICAgICAgICAgZXJyb3Iuc3RhdHVzID0gcmVzLnN0YXR1cztcbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzLmpzb24oKTtcbiAgICAgIH1cbiAgICB9fT5cbiAgICAgIDxSb3V0ZUd1YXJkPlxuICAgICAgICA8TGF5b3V0PlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgPC9MYXlvdXQ+XG4gICAgICA8L1JvdXRlR3VhcmQ+XG4gICAgPC9TV1JDb25maWc+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiTGF5b3V0IiwiU1dSQ29uZmlnIiwiUm91dGVHdWFyZCIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidmFsdWUiLCJmZXRjaGVyIiwidXJsIiwicmVzIiwiZmV0Y2giLCJvayIsImVycm9yIiwiRXJyb3IiLCJpbmZvIiwianNvbiIsInN0YXR1cyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./pages/_document.js":
/*!****************************!*\
  !*** ./pages/_document.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_document.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_document.js\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_document.js\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_document.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\_document.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQTZEO0FBRTlDLFNBQVNJO0lBQ3RCLHFCQUNFLDhEQUFDSiwrQ0FBSUE7UUFBQ0ssTUFBSzs7MEJBQ1QsOERBQUNKLCtDQUFJQTs7Ozs7MEJBQ0wsOERBQUNLOztrQ0FDQyw4REFBQ0osK0NBQUlBOzs7OztrQ0FDTCw4REFBQ0MscURBQVVBOzs7Ozs7Ozs7Ozs7Ozs7OztBQUluQiIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3BhZ2VzL19kb2N1bWVudC5qcz81MzhiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0bWwsIEhlYWQsIE1haW4sIE5leHRTY3JpcHQgfSBmcm9tIFwibmV4dC9kb2N1bWVudFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEb2N1bWVudCgpIHtcbiAgcmV0dXJuIChcbiAgICA8SHRtbCBsYW5nPVwiZW5cIj5cbiAgICAgIDxIZWFkIC8+XG4gICAgICA8Ym9keT5cbiAgICAgICAgPE1haW4gLz5cbiAgICAgICAgPE5leHRTY3JpcHQgLz5cbiAgICAgIDwvYm9keT5cbiAgICA8L0h0bWw+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiSHRtbCIsIkhlYWQiLCJNYWluIiwiTmV4dFNjcmlwdCIsIkRvY3VtZW50IiwibGFuZyIsImJvZHkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_document.js\n");

/***/ }),

/***/ "./pages/login.js":
/*!************************!*\
  !*** ./pages/login.js ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Login)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! __barrel_optimize__?names=Alert,Button,Card,Form!=!react-bootstrap */ \"__barrel_optimize__?names=Alert,Button,Card,Form!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/lib/authenticate */ \"./lib/authenticate.js\");\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/store */ \"./store.js\");\n/* harmony import */ var _lib_userData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/lib/userData */ \"./lib/userData.js\");\n/* harmony import */ var _styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/styles/Login.module.css */ \"./styles/Login.module.css\");\n/* harmony import */ var _styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__, jotai__WEBPACK_IMPORTED_MODULE_4__, _store__WEBPACK_IMPORTED_MODULE_5__, _lib_userData__WEBPACK_IMPORTED_MODULE_6__]);\n([_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__, jotai__WEBPACK_IMPORTED_MODULE_4__, _store__WEBPACK_IMPORTED_MODULE_5__, _lib_userData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\n // Import the CSS module\nfunction Login() {\n    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const [, setFavouritesList] = (0,jotai__WEBPACK_IMPORTED_MODULE_4__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_5__.favouritesAtom);\n    const [, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_4__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_5__.searchHistoryAtom);\n    const updateAtoms = async ()=>{\n        setFavouritesList(await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_6__.getFavourites)());\n        setSearchHistory(await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_6__.getHistory)());\n    };\n    const handleSubmit = async (event)=>{\n        event.preventDefault();\n        setLoading(true);\n        setError(\"\");\n        try {\n            const isAuthenticated = await (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__.authenticateUser)(user, password);\n            if (isAuthenticated) {\n                await updateAtoms(); // Update favourites and history\n                router.push(\"/favourites\"); // Redirect to favourites page\n            } else {\n                setError(\"Invalid username or password.\");\n            }\n        } catch (err) {\n            setError(err.message || \"An error occurred while logging in.\");\n        } finally{\n            setLoading(false);\n        }\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: `container ${(_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().loginContainer)}`,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Card, {\n                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().card),\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Card.Body, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                            className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().heading),\n                            children: \"Login\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 48,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                            className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().subheading),\n                            children: \"Enter your login information below:\"\n                        }, void 0, false, {\n                            fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                            lineNumber: 49,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                    lineNumber: 47,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                lineNumber: 46,\n                columnNumber: 7\n            }, this),\n            error && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Alert, {\n                variant: \"danger\",\n                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().alert),\n                children: error\n            }, void 0, false, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                lineNumber: 52,\n                columnNumber: 17\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form, {\n                onSubmit: handleSubmit,\n                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().form),\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form.Group, {\n                        className: \"mb-3\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form.Label, {\n                                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().label),\n                                children: \"User:\"\n                            }, void 0, false, {\n                                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                                lineNumber: 55,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form.Control, {\n                                type: \"text\",\n                                value: user,\n                                onChange: (e)=>setUser(e.target.value),\n                                placeholder: \"Enter username\",\n                                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().input)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                                lineNumber: 56,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                        lineNumber: 54,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form.Group, {\n                        className: \"mb-3\",\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form.Label, {\n                                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().label),\n                                children: \"Password:\"\n                            }, void 0, false, {\n                                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                                lineNumber: 65,\n                                columnNumber: 11\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Form.Control, {\n                                type: \"password\",\n                                value: password,\n                                onChange: (e)=>setPassword(e.target.value),\n                                placeholder: \"Enter password\",\n                                className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().input)\n                            }, void 0, false, {\n                                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                                lineNumber: 66,\n                                columnNumber: 11\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                        lineNumber: 64,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Alert_Button_Card_Form_react_bootstrap__WEBPACK_IMPORTED_MODULE_8__.Button, {\n                        variant: \"primary\",\n                        type: \"submit\",\n                        disabled: loading,\n                        className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_7___default().button),\n                        children: loading ? \"Logging in...\" : \"Login\"\n                    }, void 0, false, {\n                        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                        lineNumber: 74,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n                lineNumber: 53,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\SENECA\\\\SEM 4\\\\WEB 422\\\\week 13\\\\my-app\\\\pages\\\\login.js\",\n        lineNumber: 45,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9sb2dpbi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBd0M7QUFDQTtBQUNvQjtBQUNOO0FBQ3RCO0FBQzRCO0FBQ0Q7QUFDWixDQUFDLHdCQUF3QjtBQUV6RCxTQUFTYztJQUN0QixNQUFNLENBQUNDLE1BQU1DLFFBQVEsR0FBR2YsK0NBQVFBLENBQUM7SUFDakMsTUFBTSxDQUFDZ0IsVUFBVUMsWUFBWSxHQUFHakIsK0NBQVFBLENBQUM7SUFDekMsTUFBTSxDQUFDa0IsT0FBT0MsU0FBUyxHQUFHbkIsK0NBQVFBLENBQUM7SUFDbkMsTUFBTSxDQUFDb0IsU0FBU0MsV0FBVyxHQUFHckIsK0NBQVFBLENBQUM7SUFDdkMsTUFBTXNCLFNBQVNyQixzREFBU0E7SUFDeEIsTUFBTSxHQUFHc0Isa0JBQWtCLEdBQUdoQiw4Q0FBT0EsQ0FBQ0Msa0RBQWNBO0lBQ3BELE1BQU0sR0FBR2dCLGlCQUFpQixHQUFHakIsOENBQU9BLENBQUNFLHFEQUFpQkE7SUFFdEQsTUFBTWdCLGNBQWM7UUFDbEJGLGtCQUFrQixNQUFNYiw0REFBYUE7UUFDckNjLGlCQUFpQixNQUFNYix5REFBVUE7SUFDbkM7SUFFQSxNQUFNZSxlQUFlLE9BQU9DO1FBQzFCQSxNQUFNQyxjQUFjO1FBQ3BCUCxXQUFXO1FBQ1hGLFNBQVM7UUFFVCxJQUFJO1lBQ0YsTUFBTVUsa0JBQWtCLE1BQU12QixtRUFBZ0JBLENBQUNRLE1BQU1FO1lBQ3JELElBQUlhLGlCQUFpQjtnQkFDbkIsTUFBTUosZUFBZSxnQ0FBZ0M7Z0JBQ3JESCxPQUFPUSxJQUFJLENBQUMsZ0JBQWdCLDhCQUE4QjtZQUM1RCxPQUFPO2dCQUNMWCxTQUFTO1lBQ1g7UUFDRixFQUFFLE9BQU9ZLEtBQUs7WUFDWlosU0FBU1ksSUFBSUMsT0FBTyxJQUFJO1FBQzFCLFNBQVU7WUFDUlgsV0FBVztRQUNiO0lBQ0Y7SUFFQSxxQkFDRSw4REFBQ1k7UUFBSUMsV0FBVyxDQUFDLFVBQVUsRUFBRXRCLGdGQUFxQixDQUFDLENBQUM7OzBCQUNsRCw4REFBQ1IsK0ZBQUlBO2dCQUFDOEIsV0FBV3RCLHNFQUFXOzBCQUMxQiw0RUFBQ1IsK0ZBQUlBLENBQUNpQyxJQUFJOztzQ0FDUiw4REFBQ0M7NEJBQUdKLFdBQVd0Qix5RUFBYztzQ0FBRTs7Ozs7O3NDQUMvQiw4REFBQzRCOzRCQUFFTixXQUFXdEIsNEVBQWlCO3NDQUFFOzs7Ozs7Ozs7Ozs7Ozs7OztZQUdwQ00sdUJBQVMsOERBQUNiLGdHQUFLQTtnQkFBQ3FDLFNBQVE7Z0JBQVNSLFdBQVd0Qix1RUFBWTswQkFBR007Ozs7OzswQkFDNUQsOERBQUNoQiwrRkFBSUE7Z0JBQUMwQyxVQUFVbEI7Z0JBQWNRLFdBQVd0QixzRUFBVzs7a0NBQ2xELDhEQUFDViwrRkFBSUEsQ0FBQzRDLEtBQUs7d0JBQUNaLFdBQVU7OzBDQUNwQiw4REFBQ2hDLCtGQUFJQSxDQUFDNkMsS0FBSztnQ0FBQ2IsV0FBV3RCLHVFQUFZOzBDQUFFOzs7Ozs7MENBQ3JDLDhEQUFDViwrRkFBSUEsQ0FBQytDLE9BQU87Z0NBQ1hDLE1BQUs7Z0NBQ0xDLE9BQU9yQztnQ0FDUHNDLFVBQVUsQ0FBQ0MsSUFBTXRDLFFBQVFzQyxFQUFFQyxNQUFNLENBQUNILEtBQUs7Z0NBQ3ZDSSxhQUFZO2dDQUNackIsV0FBV3RCLHVFQUFZOzs7Ozs7Ozs7Ozs7a0NBRzNCLDhEQUFDViwrRkFBSUEsQ0FBQzRDLEtBQUs7d0JBQUNaLFdBQVU7OzBDQUNwQiw4REFBQ2hDLCtGQUFJQSxDQUFDNkMsS0FBSztnQ0FBQ2IsV0FBV3RCLHVFQUFZOzBDQUFFOzs7Ozs7MENBQ3JDLDhEQUFDViwrRkFBSUEsQ0FBQytDLE9BQU87Z0NBQ1hDLE1BQUs7Z0NBQ0xDLE9BQU9uQztnQ0FDUG9DLFVBQVUsQ0FBQ0MsSUFBTXBDLFlBQVlvQyxFQUFFQyxNQUFNLENBQUNILEtBQUs7Z0NBQzNDSSxhQUFZO2dDQUNackIsV0FBV3RCLHVFQUFZOzs7Ozs7Ozs7Ozs7a0NBRzNCLDhEQUFDVCxpR0FBTUE7d0JBQUN1QyxTQUFRO3dCQUFVUSxNQUFLO3dCQUFTTyxVQUFVckM7d0JBQVNjLFdBQVd0Qix3RUFBYTtrQ0FDaEZRLFVBQVUsa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLdkMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9wYWdlcy9sb2dpbi5qcz84MWIwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgRm9ybSwgQnV0dG9uLCBDYXJkLCBBbGVydCB9IGZyb20gXCJyZWFjdC1ib290c3RyYXBcIjtcclxuaW1wb3J0IHsgYXV0aGVudGljYXRlVXNlciB9IGZyb20gXCJAL2xpYi9hdXRoZW50aWNhdGVcIjtcclxuaW1wb3J0IHsgdXNlQXRvbSB9IGZyb20gXCJqb3RhaVwiO1xyXG5pbXBvcnQgeyBmYXZvdXJpdGVzQXRvbSwgc2VhcmNoSGlzdG9yeUF0b20gfSBmcm9tIFwiQC9zdG9yZVwiO1xyXG5pbXBvcnQgeyBnZXRGYXZvdXJpdGVzLCBnZXRIaXN0b3J5IH0gZnJvbSBcIkAvbGliL3VzZXJEYXRhXCI7XHJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIkAvc3R5bGVzL0xvZ2luLm1vZHVsZS5jc3NcIjsgLy8gSW1wb3J0IHRoZSBDU1MgbW9kdWxlXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpbigpIHtcclxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IFssIHNldEZhdm91cml0ZXNMaXN0XSA9IHVzZUF0b20oZmF2b3VyaXRlc0F0b20pO1xyXG4gIGNvbnN0IFssIHNldFNlYXJjaEhpc3RvcnldID0gdXNlQXRvbShzZWFyY2hIaXN0b3J5QXRvbSk7XHJcblxyXG4gIGNvbnN0IHVwZGF0ZUF0b21zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0RmF2b3VyaXRlc0xpc3QoYXdhaXQgZ2V0RmF2b3VyaXRlcygpKTtcclxuICAgIHNldFNlYXJjaEhpc3RvcnkoYXdhaXQgZ2V0SGlzdG9yeSgpKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgaXNBdXRoZW50aWNhdGVkID0gYXdhaXQgYXV0aGVudGljYXRlVXNlcih1c2VyLCBwYXNzd29yZCk7XHJcbiAgICAgIGlmIChpc0F1dGhlbnRpY2F0ZWQpIHtcclxuICAgICAgICBhd2FpdCB1cGRhdGVBdG9tcygpOyAvLyBVcGRhdGUgZmF2b3VyaXRlcyBhbmQgaGlzdG9yeVxyXG4gICAgICAgIHJvdXRlci5wdXNoKFwiL2Zhdm91cml0ZXNcIik7IC8vIFJlZGlyZWN0IHRvIGZhdm91cml0ZXMgcGFnZVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKFwiSW52YWxpZCB1c2VybmFtZSBvciBwYXNzd29yZC5cIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSB8fCBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIGxvZ2dpbmcgaW4uXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtgY29udGFpbmVyICR7c3R5bGVzLmxvZ2luQ29udGFpbmVyfWB9PlxyXG4gICAgICA8Q2FyZCBjbGFzc05hbWU9e3N0eWxlcy5jYXJkfT5cclxuICAgICAgICA8Q2FyZC5Cb2R5PlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT17c3R5bGVzLmhlYWRpbmd9PkxvZ2luPC9oMz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT17c3R5bGVzLnN1YmhlYWRpbmd9PkVudGVyIHlvdXIgbG9naW4gaW5mb3JtYXRpb24gYmVsb3c6PC9wPlxyXG4gICAgICAgIDwvQ2FyZC5Cb2R5PlxyXG4gICAgICA8L0NhcmQ+XHJcbiAgICAgIHtlcnJvciAmJiA8QWxlcnQgdmFyaWFudD1cImRhbmdlclwiIGNsYXNzTmFtZT17c3R5bGVzLmFsZXJ0fT57ZXJyb3J9PC9BbGVydD59XHJcbiAgICAgIDxGb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT17c3R5bGVzLmZvcm19PlxyXG4gICAgICAgIDxGb3JtLkdyb3VwIGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgIDxGb3JtLkxhYmVsIGNsYXNzTmFtZT17c3R5bGVzLmxhYmVsfT5Vc2VyOjwvRm9ybS5MYWJlbD5cclxuICAgICAgICAgIDxGb3JtLkNvbnRyb2xcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17dXNlcn1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB1c2VybmFtZVwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmlucHV0fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0Zvcm0uR3JvdXA+XHJcbiAgICAgICAgPEZvcm0uR3JvdXAgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgPEZvcm0uTGFiZWwgY2xhc3NOYW1lPXtzdHlsZXMubGFiZWx9PlBhc3N3b3JkOjwvRm9ybS5MYWJlbD5cclxuICAgICAgICAgIDxGb3JtLkNvbnRyb2xcclxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmlucHV0fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0Zvcm0uR3JvdXA+XHJcbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwicHJpbWFyeVwiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30gY2xhc3NOYW1lPXtzdHlsZXMuYnV0dG9ufT5cclxuICAgICAgICAgIHtsb2FkaW5nID8gXCJMb2dnaW5nIGluLi4uXCIgOiBcIkxvZ2luXCJ9XHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDwvRm9ybT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VSb3V0ZXIiLCJGb3JtIiwiQnV0dG9uIiwiQ2FyZCIsIkFsZXJ0IiwiYXV0aGVudGljYXRlVXNlciIsInVzZUF0b20iLCJmYXZvdXJpdGVzQXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIiwiZ2V0RmF2b3VyaXRlcyIsImdldEhpc3RvcnkiLCJzdHlsZXMiLCJMb2dpbiIsInVzZXIiLCJzZXRVc2VyIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImVycm9yIiwic2V0RXJyb3IiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInJvdXRlciIsInNldEZhdm91cml0ZXNMaXN0Iiwic2V0U2VhcmNoSGlzdG9yeSIsInVwZGF0ZUF0b21zIiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImlzQXV0aGVudGljYXRlZCIsInB1c2giLCJlcnIiLCJtZXNzYWdlIiwiZGl2IiwiY2xhc3NOYW1lIiwibG9naW5Db250YWluZXIiLCJjYXJkIiwiQm9keSIsImgzIiwiaGVhZGluZyIsInAiLCJzdWJoZWFkaW5nIiwidmFyaWFudCIsImFsZXJ0Iiwib25TdWJtaXQiLCJmb3JtIiwiR3JvdXAiLCJMYWJlbCIsImxhYmVsIiwiQ29udHJvbCIsInR5cGUiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsInBsYWNlaG9sZGVyIiwiaW5wdXQiLCJkaXNhYmxlZCIsImJ1dHRvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/login.js\n");

/***/ }),

/***/ "./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   favouritesAtom: () => (/* binding */ favouritesAtom),\n/* harmony export */   searchHistoryAtom: () => (/* binding */ searchHistoryAtom)\n/* harmony export */ });\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jotai */ \"jotai\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);\njotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// store.js\n\n// Create a \"favouritesAtom\" with an empty array as the default value\nconst favouritesAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n// Atom to store search history (default value is an empty array)\nconst searchHistoryAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxXQUFXO0FBQ2tCO0FBRTdCLHFFQUFxRTtBQUM5RCxNQUFNQyxpQkFBaUJELDJDQUFJQSxDQUFDLEVBQUUsRUFBRTtBQUV2QyxpRUFBaUU7QUFDMUQsTUFBTUUsb0JBQW9CRiwyQ0FBSUEsQ0FBQyxFQUFFLEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9zdG9yZS5qcz80MGY1Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHN0b3JlLmpzXHJcbmltcG9ydCB7IGF0b20gfSBmcm9tICdqb3RhaSc7XHJcblxyXG4vLyBDcmVhdGUgYSBcImZhdm91cml0ZXNBdG9tXCIgd2l0aCBhbiBlbXB0eSBhcnJheSBhcyB0aGUgZGVmYXVsdCB2YWx1ZVxyXG5leHBvcnQgY29uc3QgZmF2b3VyaXRlc0F0b20gPSBhdG9tKFtdKTtcclxuXHJcbi8vIEF0b20gdG8gc3RvcmUgc2VhcmNoIGhpc3RvcnkgKGRlZmF1bHQgdmFsdWUgaXMgYW4gZW1wdHkgYXJyYXkpXHJcbmV4cG9ydCBjb25zdCBzZWFyY2hIaXN0b3J5QXRvbSA9IGF0b20oW10pO1xyXG5cclxuIl0sIm5hbWVzIjpbImF0b20iLCJmYXZvdXJpdGVzQXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./store.js\n");

/***/ }),

/***/ "./styles/bootstrap.min.css":
/*!**********************************!*\
  !*** ./styles/bootstrap.min.css ***!
  \**********************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useIsomorphicEffect":
/*!*****************************************************!*\
  !*** external "@restart/hooks/useIsomorphicEffect" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useIsomorphicEffect");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Dropdown":
/*!***************************************!*\
  !*** external "@restart/ui/Dropdown" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Dropdown");

/***/ }),

/***/ "@restart/ui/DropdownContext":
/*!**********************************************!*\
  !*** external "@restart/ui/DropdownContext" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownContext");

/***/ }),

/***/ "@restart/ui/DropdownItem":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownItem" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownItem");

/***/ }),

/***/ "@restart/ui/DropdownMenu":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownMenu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownMenu");

/***/ }),

/***/ "@restart/ui/DropdownToggle":
/*!*********************************************!*\
  !*** external "@restart/ui/DropdownToggle" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownToggle");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "invariant":
/*!****************************!*\
  !*** external "invariant" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("invariant");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "prop-types-extra/lib/all":
/*!*******************************************!*\
  !*** external "prop-types-extra/lib/all" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types-extra/lib/all");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("warning");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "jotai":
/*!************************!*\
  !*** external "jotai" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ }),

/***/ "jwt-decode":
/*!*****************************!*\
  !*** external "jwt-decode" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = import("jwt-decode");;

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/bootstrap"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2Flogin&preferredRegion=&absolutePagePath=.%2Fpages%5Clogin.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();